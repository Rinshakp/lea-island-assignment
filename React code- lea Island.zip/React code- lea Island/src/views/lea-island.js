import React from 'react'

import { Helmet } from 'react-helmet'

import './lea-island.css'

const LeaIsland = (props) => {
  return (
    <div className="lea-island-container">
      <Helmet>
        <title>Lea-Island - Big Hearted Major Magpie</title>
        <meta
          property="og:title"
          content="Lea-Island - Big Hearted Major Magpie"
        />
      </Helmet>
    </div>
  )
}

export default LeaIsland
