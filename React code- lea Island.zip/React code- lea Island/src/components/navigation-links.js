import React from 'react'
import { Link } from 'react-router-dom'

import PropTypes from 'prop-types'

import './navigation-links.css'

const NavigationLinks = (props) => {
  return (
    <nav className={`navigation-links-nav ${props.rootClassName} `}>
      <Link to="/" className="navigation-links-navlink">
        <h4 className="navigation-links-text">{props.text}</h4>
      </Link>
      <h4 className="navigation-links-text1">{props.text1}</h4>
      <h4 className="navigation-links-text2">{props.text2}</h4>
      <a
        href="https://oiaproperties.com/"
        target="_blank"
        rel="noreferrer noopener"
        className="navigation-links-link"
      >
        <h4 className="navigation-links-text3">{props.text5}</h4>
      </a>
      <a
        href="https://oiaproperties.com/"
        target="_blank"
        rel="noreferrer noopener"
        className="navigation-links-link1"
      >
        <h4 className="navigation-links-text4">{props.text6}</h4>
      </a>
    </nav>
  )
}

NavigationLinks.defaultProps = {
  text: 'About',
  text6: 'Request Info',
  text5: 'More Projects',
  rootClassName: '',
  text2: 'Facilities',
  text1: 'Gallery',
}

NavigationLinks.propTypes = {
  text: PropTypes.string,
  text6: PropTypes.string,
  text5: PropTypes.string,
  rootClassName: PropTypes.string,
  text2: PropTypes.string,
  text1: PropTypes.string,
}

export default NavigationLinks
